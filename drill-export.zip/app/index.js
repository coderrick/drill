/* Entry point for the watch app */
console.log("App Started!");
import document from "document";

/* Retrieve heart rate */
import { HeartRateSensor } from "heart-rate";
var hrm = new HeartRateSensor();

// Load test data:
// var jsonDat = JSON.parse('testCase.json');
var jsonDat = {
    "logId": 1330991999000,
    "date": "05/18/18",
    "gender": "female",
    "activities-heart": {
       "max": 160,
       "min": 132,
       "heartRate": 146,
       "restingHeartRate": 68
    }, 
    "lbsToLose": 5,
    "weightLog": {
        "bmi": 24,
        "fat": 15,
        "MR": 1400,
    },
    "caloriesEntered": 1800,
    "percentDaysLeft": 0.30
} // testcase

// Customize progress bar:
var prog = 1 - jsonDat["percentDaysLeft"];
console.log(prog); 
var percentage = document.getElementById("progress_dynamic");
percentage.width = prog * 250;

// Customize progress percentage label:
// var percLab = document.getElementById("lab_dynamic");
// console.log(percLab.value);
// percLab.value = 100*prog + "%";
// console.log(percLab.value);
// document.getElementById("lab_dynamic").innerHTML = 100*prog + "%";

var hrText = document.getElementById("heartrate");
hrText.text += jsonDat["activities-heart"]["heartRate"];

var mrText = document.getElementById("metabolic");
mrText.text += jsonDat["weightLog"]["MR"];

var calText = document.getElementById("food");
calText.text += jsonDat["caloriesEntered"];

var goalText = document.getElementById("goal");
goalText.text = goalText.text + " " + jsonDat["lbsToLose"] + " lbs";
